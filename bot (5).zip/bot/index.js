import { Client, Collection, GatewayIntentBits, REST, Routes } from "discord.js";
import { config, isOwner } from "./config.js";
import help from "./commands/help.js";
import upload from "./commands/upload.js";
import list from "./commands/list.js";
import remove from "./commands/remove.js";
import { handleOwnerMessage } from "./owner-message.js";
import { startServer } from "./server.js";
import { migrateLegacyImages } from "./storage.js";
import { textMessage } from "./lib/components.js";
import { isBlocked } from "./storage.js";
import { logEvent } from "./logging.js";

const commands = [upload, help, list, remove];
const commandMap = new Collection(commands.map((command) => [command.data.name, command]));
const commandCooldowns = new Map();
function isOnCooldown(userId) {
  if (isOwner(userId) || config.commandCooldownSeconds <= 0) return false;
  const now = Date.now();
  const expiresAt = commandCooldowns.get(userId) ?? 0;
  if (expiresAt > now) return true;
  commandCooldowns.set(userId, now + config.commandCooldownSeconds * 1000);
  return false;
}
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    ...(config.messageContentIntent ? [GatewayIntentBits.MessageContent] : []),
  ],
});
const inviteCache = new Map();
async function cacheGuildInvites(guild) {
  const invites = await guild.invites.fetch().catch(() => null);
  if (invites) inviteCache.set(guild.id, [...invites.values()].map((invite) => invite.url));
  return inviteCache.get(guild.id) ?? [];
}
function inviteFields(urls) {
  const links = urls.length ? urls.join("\n") : "No invite links available (Manage Server permission may be missing).";
  const fields = [];
  for (let i = 0; i < links.length; i += 1000) {
    fields.push({ name: i ? "🔗 Invite links (continued)" : "🔗 All invite links", value: links.slice(i, i + 1000) });
  }
  return fields.length ? fields : [{ name: "🔗 All invite links", value: links }];
}
const rest = new REST({ version: "10" }).setToken(config.token);
await migrateLegacyImages();
startServer();

client.once("clientReady", async (readyClient) => {
  process.stdout.write(`Logged in as ${readyClient.user.tag}\n`);
  await Promise.allSettled([...client.guilds.cache.values()].map((guild) => cacheGuildInvites(guild)));
  await logEvent(client, "online", {
    title: "Bot Online",
    fields: [
      { name: "🤖 Bot", value: readyClient.user.tag },
      { name: "🌐 Servers", value: client.guilds.cache.size },
      { name: "📊 Status", value: "Connected" },
    ],
    footer: `${readyClient.user.username} • Bot Online`,
  });
});
client.on("shardReady", (shardId, unavailableGuilds) => logEvent(client, "online", {
  title: "Shard Ready",
  description: `Shard ${shardId} is ready and connected.`,
  color: 0x57f287,
  fields: [
    { name: "Latency", value: `${client.ws.ping}ms` },
    { name: "Rate Limited", value: "false" },
    { name: "Closed", value: "true" },
    { name: "Cluster", value: "1/1" },
  ],
  footer: `Aimo Music • Shard ${shardId}`,
}));
client.on("shardReconnecting", (shardId) => logEvent(client, "online", {
  title: "Shard Reconnecting",
  description: `Shard ${shardId} is reconnecting to the Gateway socket.`,
  color: 0xfee75c,
  fields: [
    { name: "Latency", value: `${client.ws.ping}ms` },
    { name: "Rate Limited", value: "false" },
    { name: "Closed", value: "false" },
    { name: "Cluster", value: "1/1" },
  ],
  footer: `Aimo Music • Shard ${shardId}`,
}));
client.on("shardResume", (shardId, replayedEvents) => logEvent(client, "online", {
  title: "Shard Resumed",
  description: `Shard ${shardId} resumed Discord Gateway session.`,
  color: 0x3498db,
  fields: [
    { name: "Latency", value: `${client.ws.ping}ms` },
    { name: "Rate Limited", value: "false" },
    { name: "Closed", value: "false" },
    { name: "Cluster", value: "1/1" },
    { name: "Replayed Events", value: `${replayedEvents}` },
  ],
  footer: `Aimo Music • Shard ${shardId}`,
}));
client.on("interactionCreate", async (interaction) => {
  if (interaction.isButton()) {
    try {
      await handleOwnerMessage(interaction, client);
    } catch (error) {
      console.error("Owner button command failed:", error);
      await interaction.reply(textMessage("Owner command failed. Check the bot logs.", { privateReply: true }));
    }
    return;
  }
  if (!interaction.isChatInputCommand()) return;
  const command = commandMap.get(interaction.commandName);
  if (!command) return;
  try {
    if (isOnCooldown(interaction.user.id)) {
      await interaction.deferReply({ ephemeral: true }).catch(() => {});
      await interaction.deleteReply().catch(() => {});
      return;
    }
    if (await isBlocked("user", interaction.user.id)) {
      await interaction.reply(textMessage("You are blacklisted from using this bot.", { privateReply: true }));
      return;
    }
    if (interaction.guildId && await isBlocked("server", interaction.guildId)) {
      await interaction.reply(textMessage("This server is blacklisted from using this bot.", { privateReply: true }));
      return;
    }
    const startedAt = Date.now();
    void logEvent(client, "commands", {
      title: "Command Used",
      fields: [
        { name: "👤 User", value: `${interaction.user.tag}\n\`${interaction.user.id}\`` },
        { name: "🏠 Server", value: interaction.guild ? `${interaction.guild.name}\n\`${interaction.guild.id}\`` : "Direct message" },
        { name: "⌨️ Command", value: `/${interaction.commandName}` },
        { name: "🔧 Type", value: "Slash" },
        { name: "📍 Channel", value: interaction.channel ? `${interaction.channel.name ?? "DM"}\n\`${interaction.channelId}\`` : "Unknown" },
      ],
      thumbnail: interaction.user.displayAvatarURL({ size: 128 }),
      footer: "Aimo Music • Slash Command",
    }).catch((error) => console.error("Command start log failed:", error.message));
    await command.execute(interaction);
    void logEvent(client, "commands", {
      title: "Command Completed",
      fields: [
        { name: "👤 User", value: `${interaction.user.tag}\n\`${interaction.user.id}\`` },
        { name: "🏠 Server", value: interaction.guild ? `${interaction.guild.name}\n\`${interaction.guild.id}\`` : "Direct message" },
        { name: "⌨️ Command", value: `/${interaction.commandName}` },
        { name: "📊 Status", value: "success" },
        { name: "⚡ Latency", value: `${Date.now() - startedAt}ms` },
      ],
      thumbnail: interaction.user.displayAvatarURL({ size: 128 }),
      footer: "Aimo Music • Slash Command",
    }).catch((error) => console.error("Command completion log failed:", error.message));
  } catch (error) {
    const message = "Something went wrong while running that command.";
    if (interaction.replied || interaction.deferred) await interaction.editReply(textMessage(message, { privateReply: true }));
    else await interaction.reply(textMessage(message, { privateReply: true }));
    void logEvent(client, "errors", {
      title: "Command Error",
      fields: [
        { name: "👤 User", value: `${interaction.user.tag}\n\`${interaction.user.id}\`` },
        { name: "🏠 Server", value: interaction.guild?.name ?? "Direct message" },
        { name: "⌨️ Command", value: `/${interaction.commandName}` },
        { name: "❌ Error", value: error.message ?? "Unknown error" },
      ],
      footer: "Aimo Music • Slash Command",
    }).catch((logError) => console.error("Command error log failed:", logError.message));
  }
});

client.on("messageCreate", async (message) => {
  if (message.author.bot || !client.user || !message.mentions.has(client.user)) return;
  try {
    const commandText = message.content.replace(new RegExp(`<@!?${client.user.id}>`), "").trim();
    const commandName = commandText.split(/\s+/)[0]?.toLowerCase();
    if (!["imglist", "ownerhelp", "bl", "slist", "ginv", "topuser", "user", "delete", "deleteuser", "deluser", "backup", "restart", "resetall"].includes(commandName)) return;
    if (isOnCooldown(message.author.id)) return;
    if (await isBlocked("user", message.author.id)) {
      await message.reply(textMessage("You are blacklisted from using this bot."));
      return;
    }
    if (message.guildId && await isBlocked("server", message.guildId)) {
      await message.reply(textMessage("This server is blacklisted from using this bot."));
      return;
    }
    await handleOwnerMessage(message, client);
    void logEvent(client, "commands", `## Owner Command\n**User:** ${message.author.tag} (\`${message.author.id}\`)\n**Command:** ${message.content.slice(0, 400)}\n**Server:** \`${message.guildId ?? "DM"}\`\n**Time:** ${new Date().toISOString()}`).catch((logError) => console.error("Owner command log failed:", logError.message));
  } catch (error) {
    console.error("Owner message command failed:", error);
    await message.reply(textMessage("Owner command failed. Check the bot logs.", { privateReply: false }));
    void logEvent(client, "errors", `## Owner Command Error\n**User:** \`${message.author.id}\`\n**Command:** ${message.content.slice(0, 400)}\n**Time:** ${new Date().toISOString()}`).catch((logError) => console.error("Owner command error log failed:", logError.message));
  }
});

client.on("guildCreate", async (guild) => {
  const inviteUrls = await cacheGuildInvites(guild);
  await logEvent(client, "serverJoin", {
    title: "Bot Added to Server",
    fields: [
      { name: "🏠 Server", value: `${guild.name}\n\`${guild.id}\`` },
      { name: "👥 Members", value: `${guild.memberCount ?? "Unknown"} total` },
      { name: "👑 Owner", value: guild.ownerId ? `\`${guild.ownerId}\`` : "Unknown" },
      { name: "💬 Channels", value: `${guild.channels.cache.filter((c) => c.isTextBased()).size} text` },
      { name: "📅 Created", value: guild.createdAt?.toLocaleString("en-GB") ?? "Unknown" },
      { name: "🌐 Servers", value: `${client.guilds.cache.size}` },
      ...inviteFields(inviteUrls),
    ],
    thumbnail: guild.iconURL({ size: 128 }),
    image: guild.bannerURL({ size: 512 }),
    footer: `Aimo Music • Server #${client.guilds.cache.size}`,
  });
});
client.on("inviteCreate", (invite) => {
  if (!invite.guild) return;
  const urls = inviteCache.get(invite.guild.id) ?? [];
  if (!urls.includes(invite.url)) inviteCache.set(invite.guild.id, [...urls, invite.url]);
});
client.on("guildDelete", async (guild) => {
  const owner = guild.ownerId ? await client.users.fetch(guild.ownerId).catch(() => null) : null;
  const inviteUrls = inviteCache.get(guild.id) ?? [];
  await logEvent(client, "serverLeave", {
    title: "Bot Removed from Server",
    fields: [
      { name: "🏠 Server", value: `${guild.name}\n\`${guild.id}\`` },
      { name: "👥 Members", value: `${guild.memberCount ?? "Unknown"}` },
      { name: "👑 Owner", value: owner ? `${owner.tag}\n\`${owner.id}\`` : (guild.ownerId ? `\`${guild.ownerId}\`` : "Could not determine") },
      { name: "🚫 Removed By", value: "Could not determine (audit log inaccessible after removal)" },
      { name: "📋 Reason", value: "No reason provided" },
      { name: "📅 Server Created", value: guild.createdAt?.toLocaleString("en-GB") ?? "Unknown" },
      { name: "⚙️ Deleted Config", value: "Configuration reset" },
      ...inviteFields(inviteUrls),
    ],
    thumbnail: guild.iconURL({ size: 128 }),
    image: guild.bannerURL({ size: 512 }),
    footer: `Aimo Music • ${client.guilds.cache.size} Servers remaining`,
  });
  inviteCache.delete(guild.id);
});

await client.login(config.token);

const applicationId = client.user.id;
const route = config.guildId
  ? Routes.applicationGuildCommands(applicationId, config.guildId)
  : Routes.applicationCommands(applicationId);
try {
  await rest.put(route, { body: commands.map((command) => command.data.toJSON()) });
  process.stdout.write(`Registered ${commands.length} slash commands for application ${applicationId}\n`);
} catch (error) {
  console.error("Slash command registration failed; the bot will continue running:", error.message);
  await logEvent(client, "errors", `## Slash Command Registration Error\n**Application:** \`${applicationId}\`\n**Guild:** \`${config.guildId ?? "Global"}\`\n**Error:** ${error.message}`);
}