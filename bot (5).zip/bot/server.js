import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { config } from "./config.js";
import { getImage } from "./storage.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const redirectUrl = process.env.SUPPORT_SERVER_URL?.trim() || "https://discord.com";

function isProtectedFile(image) {
  const originalName = image.record.originalName?.toLowerCase() ?? "";
  const contentType = image.record.contentType?.toLowerCase() ?? "";
  return config.protectedFileExtensions.some((extension) => originalName.endsWith(extension))
    || ["text/javascript", "application/javascript", "application/json", "text/css"].includes(contentType);
}

export const server = createServer(async (request, response) => {
  const url = new URL(request.url ?? "/", `http://${request.headers.host ?? "localhost"}`);

  if (request.method === "GET" && (url.pathname === "/" || url.pathname === "/index.html")) {
    const html = await readFile(path.resolve(__dirname, "../index.html"), "utf8");
    response.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    response.end(html.replaceAll("%SUPPORT_SERVER_URL%", process.env.SUPPORT_SERVER_URL ?? ""));
    return;
  }

  // Keep /image/:id as the direct image URL for Discord and non-Vercel hosting.
  // /media/:id is an alias used by the optional Vercel viewer rewrite.
  const match = url.pathname.match(/^\/(?:image|media|raw)\/([a-z0-9][a-z0-9-]{0,63})$/i);
  if (!match || !["GET", "HEAD"].includes(request.method ?? "")) {
    return response.writeHead(404).end("Not found");
  }

  try {
    const image = await getImage(match[1]);
    if (!image) return response.writeHead(404).end("Image not found");
    if (isProtectedFile(image)) {
      response.writeHead(302, { Location: redirectUrl, "Cache-Control": "no-store" }).end();
      return;
    }
    response.writeHead(200, {
      "Content-Type": image.record.contentType,
      "Content-Length": image.buffer.length,
      "Cache-Control": "public, max-age=31536000, immutable",
      "X-Content-Type-Options": "nosniff",
    });
    if (request.method === "HEAD") return response.end();
    response.end(image.buffer);
  } catch (error) {
    console.error("Unable to read hosted image:", error);
    response.writeHead(503, { "Content-Type": "text/plain; charset=utf-8" }).end("Image service unavailable");
  }
});

export function startServer() {
  server.listen(config.port, config.host, () => process.stdout.write(`Image host listening on ${config.host}:${config.port}\n`));
}