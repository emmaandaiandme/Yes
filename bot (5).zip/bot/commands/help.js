import { SlashCommandBuilder } from "discord.js";
import { textMessage } from "../lib/components.js";

export default {
  data: new SlashCommandBuilder().setName("help").setDescription("Show Image Host commands"),
  async execute(interaction) {
    await interaction.reply(textMessage(
      "## Image Host\nUpload an image and manage your own links.\n\n**/upload** — attach one image to host it.\n**/list** — show your hosted images and Markdown links.\n**/remove** — delete one of your hosted images.\n**/help** — show this guide.\n\nSupported: PNG, JPG, GIF, WebP, BMP, AVIF, TIFF · 30 MB per file.",
      { privateReply: true },
    ));
  },
};