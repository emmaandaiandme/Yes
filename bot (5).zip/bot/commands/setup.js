import { SlashCommandBuilder } from "discord.js";
import { executeSetup } from "../setup.js";

export default {
  data: new SlashCommandBuilder().setName("setup").setDescription("Configure Image Host for this channel"),
  execute: executeSetup,
};