import { SlashCommandBuilder } from "discord.js";
import { removeImage } from "../storage.js";
import { textMessage } from "../lib/components.js";

export default {
  data: new SlashCommandBuilder()
    .setName("remove")
    .setDescription("Delete one of your hosted images")
    .addStringOption((option) => option.setName("id").setDescription("Image ID or host code").setRequired(true)),
  async execute(interaction) {
    const id = interaction.options.getString("id", true).trim();
    const removed = await removeImage(id, interaction.user.id);
    await interaction.reply(textMessage(
      removed ? `Deleted **${removed.slug}** and its stored image.` : "I couldn't find an image owned by you with that ID.",
      { privateReply: true },
    ));
  },
};