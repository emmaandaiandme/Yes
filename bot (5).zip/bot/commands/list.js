import { SlashCommandBuilder } from "discord.js";
import { config } from "../config.js";
import { listImages } from "../storage.js";
import { formatBytes } from "../lib/format.js";
import { textMessage } from "../lib/components.js";

export default {
  data: new SlashCommandBuilder().setName("list").setDescription("Show your hosted images and links"),
  async execute(interaction) {
    const images = await listImages(interaction.user.id);
    if (!images.length) {
      await interaction.reply(textMessage("You have no hosted images yet. Use `/upload` to add one.", { privateReply: true }));
      return;
    }
    const baseUrl = config.publicBaseUrl.replace(/\/$/, "");
    const lines = images.slice(0, 25).map((image, index) =>
      `${index + 1}. \`${image.slug}\` · ${formatBytes(image.size)} · [Open image](${baseUrl}/image/${image.slug})`);
    await interaction.reply(textMessage(`## Your hosted images\n${lines.join("\n")}`, { privateReply: true }));
  },
};