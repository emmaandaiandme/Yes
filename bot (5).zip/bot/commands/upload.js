import { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, SlashCommandBuilder } from "discord.js";
import { config } from "../config.js";
import { findSlug, getChannelSettings, saveImage } from "../storage.js";
import { formatBytes } from "../lib/format.js";
import { getImageDimensions } from "../lib/image-info.js";
import { isValidImageBuffer } from "../lib/image-info.js";
import { uniqueHostSlug } from "../lib/names.js";
import { logEvent } from "../logging.js";
import { textMessage } from "../lib/components.js";

export default {
  data: new SlashCommandBuilder()
    .setName("upload")
    .setDescription("Host an image and get a shareable link")
    .addAttachmentOption((option) => option.setName("image").setDescription("PNG, JPG, GIF, WebP, BMP, AVIF, or TIFF").setRequired(true)),
  async execute(interaction) {
    const settings = await getChannelSettings(interaction.channelId);
    if (!settings.enabled) {
      await interaction.reply(textMessage("Image Host is disabled in this channel.", { privateReply: true }));
      return;
    }
    const attachment = interaction.options.getAttachment("image", true);
    const supportedTypes = new Set(["image/png", "image/jpeg", "image/gif", "image/webp", "image/bmp", "image/avif", "image/tiff"]);
    if (attachment.contentType?.startsWith("video/") || /\.(mp4|mov|webm|mkv|avi|m4v)$/i.test(attachment.name ?? "")) {
      await interaction.reply(textMessage("Videos are not supported. Please upload an image only.", { privateReply: true }));
      return;
    }
    if (!supportedTypes.has(attachment.contentType)) {
      await interaction.reply(textMessage("Invalid file. Please upload a valid image.", { privateReply: true }));
      return;
    }
    if (attachment.size > config.maxUploadBytes) {
      await interaction.reply(textMessage("That image is too large. The maximum size is 30 MB.", { privateReply: true }));
      return;
    }
    await interaction.deferReply({ ephemeral: true });
    try {
      const response = await fetch(attachment.url);
      if (!response.ok) throw new Error(`Download failed with ${response.status}`);
      const buffer = Buffer.from(await response.arrayBuffer());
      if (buffer.length > config.maxUploadBytes) {
        await interaction.editReply(textMessage("That image is too large. The maximum size is 30 MB.", { privateReply: true }));
        return;
      }
      if (!isValidImageBuffer(buffer, attachment.contentType)) {
        await interaction.editReply(textMessage("Invalid file. Please upload a valid image.", { privateReply: true }));
        return;
      }
      const slug = await uniqueHostSlug(findSlug);
      const record = await saveImage(interaction.user.id, attachment.name, attachment.contentType, buffer, slug);
      const baseUrl = config.publicBaseUrl.replace(/\/$/, "");
      const directUrl = `${baseUrl}/image/${record.slug}`;
      const embed = new EmbedBuilder()
        .setTitle("Details")
        .setColor(0x2b2d31)
        .addFields(
          { name: "Filename", value: `\`${record.originalName}\``, inline: false },
          { name: "Type", value: `\`${record.contentType}\``, inline: false },
          { name: "Size", value: formatBytes(record.size), inline: false },
          { name: "Dimensions", value: getImageDimensions(buffer), inline: false },
          { name: "Direct URL", value: directUrl, inline: false },
        );
      const buttons = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setLabel("Open Direct").setStyle(ButtonStyle.Link).setURL(directUrl),
      );
      await interaction.editReply({ embeds: [embed], components: [buttons] });
      await logEvent(interaction.client, "images", {
        title: "Image Hosted",
        fields: [
          { name: "Image ID", value: `\`${record.slug}\`` },
          { name: "User", value: `${interaction.user.tag}\n\`${interaction.user.id}\`` },
          { name: "Filename", value: `\`${record.originalName}\`` },
          { name: "Direct URL", value: directUrl },
        ],
        thumbnail: interaction.user.displayAvatarURL({ size: 128 }),
        footer: "Aimo Music • Image Host",
      });
    } catch {
      await interaction.editReply(textMessage("I couldn't host that image. Please try again.", { privateReply: true }));
    }
  },
};