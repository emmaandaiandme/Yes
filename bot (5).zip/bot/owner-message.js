import { config, isOwner } from "./config.js";
import { deleteUserData, getAllImagesPage, getHostingStats, listImages, resetAllData, setBlacklist } from "./storage.js";
import { textMessage } from "./lib/components.js";
import { logEvent } from "./logging.js";
import { mkdtemp, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);

function commandText(message) {
  return message.content.replace(new RegExp(`<@!?${message.client.user.id}>`), "").trim();
}

export function getOwnerCommandName(message) {
  return commandText(message).split(/\s+/)[0]?.toLowerCase() ?? "";
}

async function send(message, content, options = {}) {
  const payload = textMessage(content, options);
  if (message.isButton?.()) await message.update(payload);
  else await message.reply(payload);
}

export async function handleOwnerMessage(message, client) {
  if (message.isButton?.()) {
    if (!isOwner(message.user.id)) {
      await message.reply(textMessage("Only the bot owner can use owner commands.", { privateReply: true }));
      return;
    }
    const [, pageValue] = message.customId.split(":");
    await renderImageList(message, client, Number(pageValue) || 0);
    return;
  }
  if (!isOwner(message.author.id)) {
    await send(message, "Only the bot owner can use owner commands.");
    return;
  }
  const [command, ...args] = commandText(message).split(/\s+/);
  if (command === "imglist") {
    await renderImageList(message, client, Math.max(0, Number(args[0]) || 0));
    return;
  }
  if (command === "ownerhelp") {
    await send(message, "## Owner commands\n`imglist` · all hosted images with pages\n`bl user +/- <UserID>` · blacklist a user\n`bl server +/- <ServerID>` · blacklist a server\n`slist` · list servers and member counts\n`ginv <serverid>` · create invite\n`topuser` · top uploaders\n`user <userid>` · user links\n`delete <userid>` · delete a user’s stored data\n`backup` · DM a ZIP backup\n`restart` · restart the bot\n`resetall` · reset all stored bot data");
    return;
  }
  if (command === "restart") {
    await send(message, "Restarting the bot…");
    setTimeout(() => process.exit(0), 500);
    return;
  }
  if (command === "resetall") {
    const result = await resetAllData();
    await send(message, `## Database Reset\nDeleted **${result.images}** hosted images, **${result.blocked}** blacklist entries, and **${result.channels}** channel settings.`);
    await logEvent(client, "errors", {
      title: "Bot Data Reset",
      color: 0xfee75c,
      fields: [
        { name: "Hosted Images", value: `${result.images}` },
        { name: "Blacklist Entries", value: `${result.blocked}` },
        { name: "Channel Settings", value: `${result.channels}` },
      ],
      footer: "Aimo Music • Auto Data Cleanup",
    });
    return;
  }
  if (command === "delete" || command === "deleteuser" || command === "deluser") {
    const userId = args[0]?.replace(/[<@!>]/g, "").trim();
    if (!/^\d{15,25}$/.test(userId ?? "")) {
      await send(message, "Usage: `delete <UserID>`.");
      return;
    }
    const result = await deleteUserData(userId);
    await send(message, `## User Data Deleted\nUser \`${userId}\` data was removed.\n\n**Database images:** ${result.images}\n**Upload files:** ${result.files}\n**Blacklist entries:** ${result.blocked}`);
    await logEvent(client, "commands", {
      title: "User Data Deleted",
      fields: [
        { name: "User ID", value: `\`${userId}\`` },
        { name: "Database Images", value: `${result.images}` },
        { name: "Upload Files", value: `${result.files}` },
        { name: "Blacklist Entries", value: `${result.blocked}` },
      ],
      footer: "Aimo Music • Privacy Request",
    });
    return;
  }
  if (command === "backup") {
    await createOwnerBackup(message);
    return;
  }
  if (command === "bl") {
    const type = args[0];
    const action = args[1];
    const id = args[2]?.trim();
    if (!["user", "server"].includes(type) || !["+", "-"].includes(action) || !id) {
      await send(message, "Usage: `bl user +/- <UserID>` or `bl server +/- <ServerID>`.");
      return;
    }
    await setBlacklist(type, id, action === "+");
    await send(message, `${action === "+" ? "Blacklisted" : "Removed from blacklist"} ${type} \`${id}\`.`);
    return;
  }
  if (command === "slist") {
    const guilds = [...client.guilds.cache.values()];
    await send(message, `## Servers · ${guilds.length}\n${guilds.map((guild) => `• **${guild.name}** — \`${guild.id}\`\n  👥 Members: **${guild.memberCount ?? "Unknown"}**`).join("\n") || "No servers found."}`);
    return;
  }
  if (command === "ginv") {
    const guild = client.guilds.cache.get(args[0]);
    if (!guild) return send(message, "I can't find that server ID.");
    const channel = guild.channels.cache.find((candidate) => candidate.isTextBased() && candidate.permissionsFor(guild.members.me)?.has("CreateInstantInvite"));
    if (!channel) return send(message, "I can't create an invite in that server.");
    const invite = await channel.createInvite({ maxAge: 0, maxUses: 0, unique: true });
    await send(message, `## Invite · ${guild.name}\n**Created by:** ${message.author.tag} (\`${message.author.id}\`)\n[Open server invite](${invite.url})`);
    await logEvent(client, "commands", `## Invite Created\n**Created by:** ${message.author.tag} (\`${message.author.id}\`)\n**Server:** ${guild.name} (\`${guild.id}\`)\n**Invite:** ${invite.url}\n**Time:** ${new Date().toISOString()}`);
    return;
  }
  if (command === "topuser") {
    const stats = await getHostingStats(10);
    const lines = await Promise.all(stats.map(async (entry, index) => {
      const user = await client.users.fetch(entry.ownerId).catch(() => null);
      return `${index + 1}. ${user ? `${user.tag} (\`${user.id}\`)` : `\`${entry.ownerId}\``} — **${entry.imageCount}** images`;
    }));
    await send(message, `## Top image hosts\n${lines.join("\n") || "No hosted images yet."}`);
    return;
  }
  if (command === "user") {
    const userId = args[0];
    if (!userId) return send(message, "Usage: `@Image Host user <UserID>`");
    const images = await listImages(userId);
    const baseUrl = config.publicBaseUrl.replace(/\/$/, "");
    await send(message, `## Hosted links for \`${userId}\`\n${images.map((image) => `• \`${image.slug}\` — [Open image](${baseUrl}/image/${image.slug})`).join("\n") || "No hosted images."}`);
    return;
  }
  await send(message, "Use `ownerhelp` to see owner commands.");
}

async function createOwnerBackup(message) {
  const tempDir = await mkdtemp(path.join(os.tmpdir(), "image-host-backup-"));
  const zipPath = path.join(tempDir, `image-host-backup-${Date.now()}.zip`);
  try {
    await execFileAsync("zip", ["-r", zipPath, "bot", "uploads", "-x", "uploads/*.zip"], { cwd: process.cwd(), maxBuffer: 1024 * 1024 });
    await message.author.send({
      content: "Your Image Host backup is attached. It contains the bot and uploads folders; secrets are not included.",
      files: [zipPath],
    });
    await send(message, "Backup ZIP sent to your owner DM.");
  } catch (error) {
    console.error("Backup failed:", error);
    await send(message, "I couldn't send the backup. Check that your DMs are open and ZIP is available.");
  } finally {
    await rm(tempDir, { recursive: true, force: true });
  }
}

async function renderImageList(message, client, page) {
  const result = await getAllImagesPage(page, 10);
  const totalPages = Math.max(1, Math.ceil(result.total / result.pageSize));
  const baseUrl = config.publicBaseUrl.replace(/\/$/, "");
  const lines = await Promise.all(result.images.map(async (image, index) => {
    const user = await client.users.fetch(image.ownerId).catch(() => null);
    const created = new Date(image.createdAt).toLocaleString("en-GB", { dateStyle: "medium", timeStyle: "short" });
    return `${result.page * result.pageSize + index + 1}. \`${image.slug}\` · ${user ? `${user.tag} (\`${user.id}\`)` : `\`${image.ownerId}\``}\n[Open image](${baseUrl}/image/${image.slug}) · ${image.originalName} · ${created}`;
  }));
  await send(
    message,
    `## All hosted images\n${lines.join("\n\n") || "No hosted images yet."}\n\nPage **${result.page + 1}** of **${totalPages}** · ${result.total} total`,
    {
      buttons: [
        { label: "Previous", customId: `owner-imglist:${Math.max(0, result.page - 1)}`, disabled: result.page <= 0 },
        { label: "Next", customId: `owner-imglist:${Math.min(totalPages - 1, result.page + 1)}`, disabled: result.page >= totalPages - 1 },
      ],
    },
  );
}