import path from "node:path";
import { readFileSync } from "node:fs";

function loadSystemConfig() {
  for (const systemPath of [path.resolve("system.json"), path.resolve("../system.json")]) {
    try {
      return JSON.parse(readFileSync(systemPath, "utf8"));
    } catch (error) {
      if (error.code !== "ENOENT") {
        console.error("Unable to read system.json:", error.message);
        return {};
      }
    }
  }
  return {};
}

function loadDotEnv() {
  const envPaths = [path.resolve("bot-app/.env"), path.resolve(".env")];
  for (const envPath of envPaths) {
    try {
      const contents = readFileSync(envPath, "utf8");
    for (const line of contents.split(/\r?\n/)) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) continue;
      const separator = trimmed.indexOf("=");
      if (separator < 1) continue;
      const key = trimmed.slice(0, separator).trim();
      let value = trimmed.slice(separator + 1).trim();
      if ((value.startsWith("\"") && value.endsWith("\"")) || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      const isTemplateValue = /^(replace_with_|your_|https:\/\/your-)/i.test(value);
      // Replit may inject a protected secret name as an empty placeholder.
      // In that case, use the existing local .env value without ever logging it.
      if (!isTemplateValue && (!process.env[key] || process.env[key].trim() === "")) process.env[key] = value;
    }
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
  }
}

loadDotEnv();
const system = loadSystemConfig();

const optionalEnv = (name) => {
  const value = process.env[name]?.trim();
  return value && !/^(replace_with_|your_|https:\/\/your-)/i.test(value) ? value : undefined;
};

const required = (name) => {
  const value = process.env[name];
  if (!value) throw new Error(`${name} is required`);
  return value;
};

export const config = {
  token: required("DISCORD_BOT_TOKEN"),
  clientId: optionalEnv("DISCORD_CLIENT_ID"),
  guildId: optionalEnv("DISCORD_GUILD_ID"),
  ownerIds: (process.env.BOT_OWNER_IDS ?? process.env.BOT_OWNER_ID ?? "1177916951734009929")
    .split(",")
    .map((value) => value.trim())
    .filter(Boolean),
  messageContentIntent: process.env.ENABLE_MESSAGE_CONTENT_INTENT === "true",
  logChannels: {
    online: process.env.ONLINE_LOG_CHANNEL_ID,
    commands: process.env.COMMANDS_LOG_CHANNEL_ID,
    serverLeave: process.env.SERVER_LEAVE_LOG_CHANNEL_ID,
    serverJoin: process.env.SERVER_JOIN_LOG_CHANNEL_ID,
    errors: process.env.ERROR_LOG_CHANNEL_ID,
    images: process.env.IMAGE_HOST_LOG_CHANNEL_ID,
  },
  host: process.env.HOST ?? "0.0.0.0",
  port: Number(process.env.PORT ?? 3000),
  publicBaseUrl: optionalEnv("PUBLIC_BASE_URL") ??
    (process.env.REPLIT_DEV_DOMAIN ? `https://${process.env.REPLIT_DEV_DOMAIN}` : "http://localhost:3000"),
  uploadDir: path.resolve(process.env.UPLOAD_DIR ?? "uploads"),
  databaseFile: process.env.DATABASE_FILE ?? "data.db",
  maxUploadBytes: 30 * 1024 * 1024,
  commandCooldownSeconds: Math.max(0, Number(system.commandCooldownSeconds) || 30),
  protectedFileExtensions: Array.isArray(system.protectedFileExtensions)
    ? system.protectedFileExtensions.map((extension) => String(extension).toLowerCase())
    : [".js", ".json", ".css"],
};

export function isOwner(userId) {
  return config.ownerIds.includes(userId);
}