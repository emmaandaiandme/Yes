import { config } from "./config.js";
import { EmbedBuilder } from "discord.js";

const channelKeys = {
  online: "online",
  commands: "commands",
  serverLeave: "serverLeave",
  serverJoin: "serverJoin",
  errors: "errors",
  images: "images",
};

const colors = {
  online: 0x57f287,
  commands: 0x5865f2,
  serverJoin: 0x57f287,
  serverLeave: 0xed4245,
  errors: 0xfaa61a,
  images: 0x3498db,
};

const emojis = {
  online: "🟢",
  commands: "📝",
  serverJoin: "📥",
  serverLeave: "📤",
  errors: "⚠️",
  images: "🖼️",
};
const channelCache = new Map();

function legacyEvent(content) {
  const [titleLine, ...descriptionLines] = content.split("\n");
  return {
    title: titleLine.replace(/^#+\s*/, "").trim(),
    description: descriptionLines.join("\n"),
  };
}

function addFields(embed, fields = []) {
  const validFields = fields
    .filter((field) => field?.name && field.value !== undefined && field.value !== null)
    .slice(0, 25)
    .map((field) => ({
      name: String(field.name).slice(0, 256),
      value: String(field.value).slice(0, 1024) || "—",
      inline: Boolean(field.inline),
    }));
  if (validFields.length) embed.addFields(validFields);
  return embed;
}

export async function logEvent(client, type, content) {
  const channelId = config.logChannels[channelKeys[type] ?? type];
  if (!channelId) return;
  let channel = channelCache.get(channelId);
  if (!channel) {
    channel = await client.channels.fetch(channelId).catch(() => null);
    if (channel) channelCache.set(channelId, channel);
  }
  if (!channel?.isTextBased()) return;
  const event = typeof content === "string" ? legacyEvent(content) : content;
  const embed = new EmbedBuilder()
    .setColor(event.color ?? colors[type] ?? 0x5865f2)
    .setTitle(`${emojis[type] ?? "📌"} ${event.title}`.slice(0, 256))
    .setTimestamp();
  if (event.description) embed.setDescription(event.description.slice(0, 4096));
  addFields(embed, event.fields);
  if (event.thumbnail) embed.setThumbnail(event.thumbnail);
  if (event.image) embed.setImage(event.image);
  if (event.author?.name) embed.setAuthor({ name: event.author.name, iconURL: event.author.iconURL });
  embed.setFooter({ text: event.footer ?? "Aimo Music" });
  await channel.send({ embeds: [embed], allowedMentions: { parse: [] } }).catch((error) => {
    console.error(`Unable to write ${type} log:`, error.message);
  });
}