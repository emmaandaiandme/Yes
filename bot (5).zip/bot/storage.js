import { mkdirSync } from "node:fs";
import { readFile, readdir, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";
import Database from "better-sqlite3";
import { config } from "./config.js";

mkdirSync(config.uploadDir, { recursive: true });
const databasePath = path.join(config.uploadDir, config.databaseFile);
const db = new Database(databasePath);
db.exec(`
  PRAGMA journal_mode = WAL;
  CREATE TABLE IF NOT EXISTS hosted_images (
    id TEXT PRIMARY KEY,
    owner_id TEXT NOT NULL,
    original_name TEXT NOT NULL,
    content_type TEXT NOT NULL,
    size_bytes INTEGER NOT NULL,
    data BLOB NOT NULL,
    created_at TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE
  );
  CREATE TABLE IF NOT EXISTS blocked_entities (
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (entity_type, entity_id)
  );
  CREATE TABLE IF NOT EXISTS channel_settings (
    channel_id TEXT PRIMARY KEY,
    enabled INTEGER NOT NULL DEFAULT 1,
    auto_delete INTEGER NOT NULL DEFAULT 0,
    spoiler INTEGER NOT NULL DEFAULT 0,
    show_direct INTEGER NOT NULL DEFAULT 1,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);

const mapImage = (row) => ({
  id: row.id,
  ownerId: row.owner_id,
  originalName: row.original_name,
  contentType: row.content_type,
  slug: row.slug,
  size: Number(row.size_bytes),
  createdAt: row.created_at,
});

export async function saveImage(ownerId, originalName, contentType, buffer, slug) {
  if (!Buffer.isBuffer(buffer) || buffer.length === 0) throw new Error("Cannot save an empty image");
  const record = {
    id: randomUUID(),
    ownerId,
    originalName,
    contentType,
    slug,
    size: buffer.length,
    createdAt: new Date().toISOString(),
  };
  db.prepare(
    `INSERT INTO hosted_images (id, owner_id, original_name, content_type, size_bytes, data, created_at, slug)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(record.id, record.ownerId, record.originalName, record.contentType, record.size, buffer, record.createdAt, record.slug);
  return record;
}

export async function getImage(identifier) {
  const row = db.prepare(
    `SELECT id, owner_id, original_name, content_type, size_bytes, data, created_at, slug
     FROM hosted_images WHERE id = ? OR slug = ? ORDER BY CASE WHEN slug = ? THEN 0 ELSE 1 END LIMIT 1`,
  ).get(identifier, identifier, identifier);
  if (!row) return null;
  return { record: mapImage(row), buffer: Buffer.from(row.data) };
}

export async function listImages(ownerId) {
  return db.prepare(
    `SELECT id, owner_id, original_name, content_type, size_bytes, created_at, slug
     FROM hosted_images WHERE owner_id = ? ORDER BY created_at DESC`,
  ).all(ownerId).map(mapImage);
}

export async function getHostingStats(limit = 10) {
  const safeLimit = Math.max(1, Math.min(100, Math.trunc(Number(limit) || 10)));
  return db.prepare(
    `SELECT owner_id, COUNT(*) AS image_count, MAX(created_at) AS last_upload
     FROM hosted_images GROUP BY owner_id ORDER BY image_count DESC, last_upload DESC LIMIT ?`,
  ).all(safeLimit).map((row) => ({ ownerId: row.owner_id, imageCount: Number(row.image_count), lastUpload: row.last_upload }));
}

export async function getAllImagesPage(page = 0, pageSize = 10) {
  const safePage = Math.max(0, Number(page) || 0);
  const safePageSize = Math.max(1, Math.min(100, Math.trunc(Number(pageSize) || 10)));
  const total = Number(db.prepare("SELECT COUNT(*) AS total FROM hosted_images").get().total);
  const images = db.prepare(
    `SELECT id, owner_id, original_name, content_type, size_bytes, created_at, slug
     FROM hosted_images ORDER BY created_at DESC LIMIT ? OFFSET ?`,
  ).all(safePageSize, safePage * safePageSize).map(mapImage);
  return { total, page: safePage, pageSize: safePageSize, images };
}

export async function setBlacklist(type, id, blocked) {
  if (!["user", "server"].includes(type)) throw new Error("Invalid blacklist type");
  if (blocked) db.prepare("INSERT OR IGNORE INTO blocked_entities (entity_type, entity_id) VALUES (?, ?)").run(type, id);
  else db.prepare("DELETE FROM blocked_entities WHERE entity_type = ? AND entity_id = ?").run(type, id);
}

export async function isBlocked(type, id) {
  if (!id) return false;
  return Boolean(db.prepare("SELECT 1 FROM blocked_entities WHERE entity_type = ? AND entity_id = ? LIMIT 1").get(type, id));
}

export async function getChannelSettings(channelId) {
  const row = db.prepare(
    "SELECT channel_id, enabled, auto_delete, spoiler, show_direct FROM channel_settings WHERE channel_id = ?",
  ).get(channelId);
  return row
    ? { channelId: row.channel_id, enabled: Boolean(row.enabled), autoDelete: Boolean(row.auto_delete), spoiler: Boolean(row.spoiler), showDirect: Boolean(row.show_direct) }
    : { channelId, enabled: true, autoDelete: false, spoiler: false, showDirect: true };
}

export async function updateChannelSetting(channelId, setting, value) {
  const columns = { enabled: "enabled", autoDelete: "auto_delete", spoiler: "spoiler", showDirect: "show_direct" };
  const column = columns[setting];
  if (!column) throw new Error("Invalid channel setting");
  db.prepare(
    `INSERT INTO channel_settings (channel_id, ${column}, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)
     ON CONFLICT(channel_id) DO UPDATE SET ${column} = excluded.${column}, updated_at = CURRENT_TIMESTAMP`,
  ).run(channelId, value ? 1 : 0);
  return getChannelSettings(channelId);
}

export async function findSlug(slug) {
  return db.prepare("SELECT slug FROM hosted_images WHERE slug = ? LIMIT 1").get(slug)?.slug ?? null;
}

export async function removeImage(id, ownerId) {
  return db.prepare(
    "DELETE FROM hosted_images WHERE (id = ? OR slug = ?) AND owner_id = ? RETURNING id, slug, original_name, size_bytes",
  ).get(id, id, ownerId) ?? null;
}

export async function migrateLegacyImages() {
  const metadataPath = path.join(config.uploadDir, "metadata.json");
  try {
    const records = JSON.parse(await readFile(metadataPath, "utf8"));
    for (const record of records) {
      const buffer = await readFile(path.join(config.uploadDir, record.id));
      db.prepare(
        `INSERT OR IGNORE INTO hosted_images (id, owner_id, original_name, content_type, size_bytes, data, created_at, slug)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      ).run(record.id, record.ownerId, record.originalName, record.contentType, buffer.length, buffer, record.createdAt, record.slug ?? record.id);
    }
  } catch (error) {
    if (error.code !== "ENOENT") console.error("Legacy image migration skipped:", error.message);
  }
}

export function closeStorage() {
  db.close();
}

export async function resetAllData() {
  const images = Number(db.prepare("SELECT COUNT(*) AS total FROM hosted_images").get().total);
  const blocked = Number(db.prepare("SELECT COUNT(*) AS total FROM blocked_entities").get().total);
  const channels = Number(db.prepare("SELECT COUNT(*) AS total FROM channel_settings").get().total);
  db.exec("DELETE FROM hosted_images; DELETE FROM blocked_entities; DELETE FROM channel_settings;");
  const keep = new Set([config.databaseFile, `${config.databaseFile}-wal`, `${config.databaseFile}-shm`]);
  const files = await readdir(config.uploadDir).catch(() => []);
  await Promise.all(files.filter((file) => !keep.has(file)).map((file) => rm(path.join(config.uploadDir, file), { force: true, recursive: true })));
  return { images, blocked, channels };
}

export async function deleteUserData(userId) {
  const imageIds = db.prepare("SELECT id FROM hosted_images WHERE owner_id = ?").all(userId).map((row) => row.id);
  const blocked = Number(
    db.prepare("SELECT COUNT(*) AS total FROM blocked_entities WHERE entity_type = 'user' AND entity_id = ?").get(userId).total,
  );
  db.prepare("DELETE FROM hosted_images WHERE owner_id = ?").run(userId);
  db.prepare("DELETE FROM blocked_entities WHERE entity_type = 'user' AND entity_id = ?").run(userId);

  const metadataPath = path.join(config.uploadDir, "metadata.json");
  let legacyFiles = 0;
  try {
    const records = JSON.parse(await readFile(metadataPath, "utf8"));
    const remaining = [];
    for (const record of records) {
      if (String(record.ownerId) !== String(userId)) {
        remaining.push(record);
        continue;
      }
      await rm(path.join(config.uploadDir, record.id), { force: true });
      legacyFiles += 1;
    }
    await writeFile(metadataPath, `${JSON.stringify(remaining, null, 2)}\n`, "utf8");
  } catch (error) {
    if (error.code !== "ENOENT" && error.name !== "SyntaxError") throw error;
  }

  await Promise.all(imageIds.map((id) => rm(path.join(config.uploadDir, id), { force: true })));
  return { images: imageIds.length, files: legacyFiles, blocked };
}