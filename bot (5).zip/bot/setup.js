import { PermissionFlagsBits } from "discord.js";
import { getChannelSettings, updateChannelSetting } from "./storage.js";
import { textMessage } from "./lib/components.js";

function panel(settings) {
  const state = (value) => value ? "ON" : "OFF";
  return textMessage(
    `## Image Host setup\nConfigure Image Host for this channel.\n\n` +
    `**Image Host:** ${state(settings.enabled)}\n` +
    `**Auto-delete bot messages:** ${state(settings.autoDelete)}\n` +
    `**Spoiler uploads:** ${state(settings.spoiler)}\n` +
    `**Show image directly:** ${state(settings.showDirect)}\n\n` +
    `Only Image Host controls are available here. No third-party providers and no delete button.`,
    {
      privateReply: true,
      buttons: [
        { label: `Image Host ${state(settings.enabled)}`, customId: `setup:${settings.channelId}:enabled` },
        { label: `Auto-delete ${state(settings.autoDelete)}`, customId: `setup:${settings.channelId}:autoDelete` },
        { label: `Spoiler ${state(settings.spoiler)}`, customId: `setup:${settings.channelId}:spoiler` },
        { label: `Show directly ${state(settings.showDirect)}`, customId: `setup:${settings.channelId}:showDirect` },
      ],
    },
  );
}

export async function executeSetup(interaction) {
  if (!interaction.guildId) {
    await interaction.reply(textMessage("Setup can only be used inside a server.", { privateReply: true }));
    return;
  }
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
    await interaction.reply(textMessage("You need Manage Server permission to use setup.", { privateReply: true }));
    return;
  }
  await interaction.reply(panel(await getChannelSettings(interaction.channelId)));
}

export async function handleSetupButton(interaction) {
  const [, channelId, setting] = interaction.customId.split(":");
  if (interaction.channelId !== channelId) {
    await interaction.reply(textMessage("This setup panel belongs to another channel.", { privateReply: true }));
    return;
  }
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
    await interaction.reply(textMessage("You need Manage Server permission to change setup.", { privateReply: true }));
    return;
  }
  const current = await getChannelSettings(channelId);
  await interaction.update(panel(await updateChannelSetting(channelId, setting, !current[setting])));
}